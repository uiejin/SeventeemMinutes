\connect zulip
CREATE EXTENSION pgroonga;
GRANT USAGE ON SCHEMA pgroonga TO zulip;
