# Load AppConfig app subclass by default on django applications initialization
default_app_config = 'zerver.apps.ZerverConfig'
